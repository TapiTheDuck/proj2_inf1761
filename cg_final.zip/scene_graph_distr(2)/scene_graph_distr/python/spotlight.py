from __future__ import annotations

import math
from typing import Any

import graphics_math as gm

from light import Light


class SpotLight(Light):
    """Spot light: position (spos), direction (sdir), aperture angle (theta)
    and concentration exponent (sexp), besides the colors inherited from
    Light.

    Position (w = 1) and direction (w = 0, renormalized) are mapped to the
    shader's lighting space by map(); cos(theta) and sexp are sent as they
    are. The spot coefficient is computed per fragment by the shader, which
    must declare these fields in its "global" block:
      light_position  : vec4<f32>
      light_direction : vec3<f32>
      light_cutoff    : f32  (cos(theta), already computed here)
      light_exponent  : f32  (sexp)"""

    def __init__ (self, px: float, py: float, pz: float,
                  dx: float, dy: float, dz: float,
                  angle_degrees: float, exponent: float,
                  space: str = "world", **values: Any) -> None:
      Light.__init__(self, space, **values)
      self.set_position(px, py, pz)
      self.set_direction(dx, dy, dz)
      self.set_cutoff_angle(angle_degrees)
      self.set_exponent(exponent)

    def set_position (self, x: float, y: float, z: float) -> None:
      self.set("light_position", gm.vec4(x, y, z, 1.0))

    def set_direction (self, x: float, y: float, z: float) -> None:
      if x == 0 and y == 0 and z == 0:
        raise ValueError("SpotLight direction must not be the zero vector")
      self.set("light_direction", gm.vec3(x, y, z))

    def set_cutoff_angle (self, angle_degrees: float) -> None:
      """Aperture angle theta, in degrees, in (0, 90]."""
      if not 0 < angle_degrees <= 90:
        raise ValueError("SpotLight aperture angle must be in (0, 90] degrees")
      # the shader tests c >= cos(theta), so the cosine is computed once, here
      self.set("light_cutoff", math.cos(math.radians(angle_degrees)))

    def set_exponent (self, exponent: float) -> None:
      """Concentration exponent sexp >= 0 (0 = constant inside the cone)."""
      if exponent < 0:
        raise ValueError("SpotLight exponent must be >= 0")
      self.set("light_exponent", float(exponent))

    def map (self, matrix: gm.Mat4) -> dict[str, Any]:
      position = self.get("light_position")
      d = self.get("light_direction")
      direction = (matrix @ gm.vec4(d[0], d[1], d[2], 0.0))[:3]
      return {"light_position": matrix @ position,
              "light_direction": gm.normalize(direction)}
