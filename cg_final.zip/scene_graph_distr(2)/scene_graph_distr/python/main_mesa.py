from __future__ import annotations

from pathlib import Path
from typing import Any

import graphics_math as gm
import wgpu
from rendercanvas.glfw import RenderCanvas, loop

from camera3d import *
from spotlight import *
from pointlight import *
from shader import *
from pipeline import *
from phongmaterial import *
from texture import *
from sampler import *
from textureset import *
from transform import *
from node import *
from scene import *
from renderer import *
from cube import *
from sphere import *

canvas: RenderCanvas
device: wgpu.GPUDevice
context: Any
renderer: Renderer
camera: Camera3D
scene: Scene

viewer_pos: gm.Vec3 = gm.vec3(2.0, 3.5, 4.0)

PROJECT_ROOT = Path(__file__).resolve().parent.parent
IMAGE_ROOT = PROJECT_ROOT / "images"
SHADER_ROOT = PROJECT_ROOT / "shaders"


def make_leg (pipeline_tex: Pipeline, material: PhongMaterial, textures: TextureSet,
              cube: Cube, x: float, z: float, height: float, width: float) -> Node:
  """Pe da mesa: cubo fino e comprido indo de y=-height ate y=0."""
  trf = Transform()
  trf.translate(x, -height, z)
  trf.scale(width, height, width)
  return Node(pipeline_tex, trf, [material, textures], [cube])


def configure_global_effects(shader: Shader, second_light: PointLight) -> None:
  """Sets the extra point light and linear fog fields declared by the Mesa shaders."""
  position = second_light.get("light_position")
  diffuse = second_light.get("light_diffuse")
  specular = second_light.get("light_specular")
  shader.set_value("light2.position", position)
  shader.set_value("light2.diffuse", gm.vec4(diffuse[0], diffuse[1], diffuse[2], 0.0))
  shader.set_value("light2.specular", gm.vec4(specular[0], specular[1], specular[2], 0.0))
  shader.set_value("fog_color", gm.vec4(0.78, 0.84, 0.92, 1.0))
  shader.set_value("fog_start", 3.0)
  shader.set_value("fog_end", 10.0)

def initialize (device: wgpu.GPUDevice, target_format: str) -> None:
  global camera, scene

  camera = Camera3D(viewer_pos[0], viewer_pos[1], viewer_pos[2])
  arcball = camera.create_arcball()
  arcball.attach(canvas)

  # Luz de SPOT fixa no mundo, 5 unidades acima do centro da mesa e
  # apontando para baixo. Abertura 20 graus, expoente 20.
  light = SpotLight(0.0, 5.0, 0.0,    # spos
                    0.0, -1.0, 0.0,   # sdir
                    20.0,             # theta (graus)
                    20.0,             # sexp
                    space="world")
  light.set_ambient(0.06, 0.06, 0.06)
  light.set_diffuse(0.30, 0.34, 0.38)
  light.set_specular(0.30, 0.34, 0.38)
  # Luz pontual âmbar bem próxima ao tampo, no quadrante esquerdo/frontal.
  # A atenuação no shader faz o ponto de incidência ficar claramente visível.
  second_light = PointLight(-1.2, 1.0, 1.0, space="world")
  second_light.set_diffuse(2.8, 0.55, 0.18)
  second_light.set_specular(2.8, 0.55, 0.18)

  # Materiais. Nos objetos com decal, a textura MODULA a cor base: o marrom
  # da mesa vira madeira (tabuas com veios, table_wood.png), e o amarelo do bloco
  # tinge o tijolo de cinza claro (a argamassa fica amarelo escuro).
  brown = PhongMaterial(1.00, 0.70, 0.45)   # mesa e pes (com textura)
  yellow = PhongMaterial(0.90, 0.80, 0.10)  # bloco (com textura)
  red = PhongMaterial(0.80, 0.10, 0.10)     # bola vermelha (lisa)
  red.set_specular(2.0, 2.0, 2.0)           # realça a variação do mapa de rugosidade
  green = PhongMaterial(0.10, 0.70, 0.20)   # bola verde (lisa)

  # Texturas de decal (padronagem de cor)
  wood = Texture(device, "decal_texture", str(IMAGE_ROOT / "table_wood.png"))
  brick = Texture(device, "decal_texture", str(IMAGE_ROOT / "block_brick.png"))
  decal_sampler = Sampler(device, "decal_sampler")
  normal_map = Texture(device, "normal_texture", str(IMAGE_ROOT / "earth-normal.png"))
  normal_sampler = Sampler(device, "normal_sampler")
  flat_normal = Texture(device, "normal_texture", None, texel=gm.vec3(0.5, 0.5, 1.0))
  roughness_map = Texture(device, "roughness_texture", str(IMAGE_ROOT / "noise.png"))
  roughness_sampler = Sampler(device, "roughness_sampler")
  wood_set = TextureSet([wood, decal_sampler])
  brick_set = TextureSet([brick, decal_sampler])

  # Transformacoes. Transform multiplica pela direita: a ULTIMA chamada e
  # aplicada primeiro aos vertices. Com translate() antes de scale(), a
  # escala age no objeto e a translacao fica em unidades de MUNDO.
  # O cubo vai de -0.5 a 0.5 em x/z e de 0 a 1 em y (base em y=0); a
  # esfera tem raio 1 e e centrada na origem.
  table_top = 0.3
  trf_table = Transform()                       # tampo 4 x 0.3 x 4, base em y=0
  trf_table.scale(4.0, table_top, 4.0)

  red_radius = 0.65                             # maior para destacar o mapa na esfera
  trf_red = Transform()
  trf_red.translate(-1.0, table_top + red_radius, 0.0)
  trf_red.scale(red_radius, red_radius, red_radius)

  block_height = 0.4                            # retangulo amarelo na mesa
  trf_yellow = Transform()
  trf_yellow.translate(1.0, table_top, 0.0)
  trf_yellow.scale(1.0, block_height, 1.0)

  green_radius = 0.3                            # bola verde, menor que a vermelha,
  trf_green = Transform()                       # exatamente sobre o retangulo
  trf_green.translate(1.0, table_top + block_height + green_radius, 0.0)
  trf_green.scale(green_radius, green_radius, green_radius)

  cube = Cube(device)
  sphere = Sphere(device)

  # Pipeline 1: spot por fragmento, SEM textura (as duas bolas)
  shader = Shader(device, str(SHADER_ROOT / "ilum_frag" / "spot.wgsl"), light=light, space="world")
  configure_global_effects(shader, second_light)
  shader.set_vertex_buffers([
    {"array_stride": 3 * 4, "step_mode": "vertex",
     "attributes": [{"format": "float32x3", "offset": 0, "var_name": "coord"}]},
    {"array_stride": 3 * 4, "step_mode": "vertex",
     "attributes": [{"format": "float32x3", "offset": 0, "var_name": "normal"}]},
  ])
  pipeline = Pipeline(shader, target_format, primitive={"cull_mode": "back"})

  # Pipeline 2: spot por fragmento COM decal (mesa, pes e bloco). Cube e
  # Sphere tem 4 buffers (slots 0=coord, 1=normal, 2=tangent, 3=texcoord) e
  # a lista abaixo e posicional, entao o shader declara os 4 (a tangente
  # nao e usada) para que cada slot case com um @location.
  shd_tex = Shader(device, str(SHADER_ROOT / "ilum_frag" / "spot_textured.wgsl"), light=light, space="world")
  configure_global_effects(shd_tex, second_light)
  shd_tex.set_vertex_buffers([
    {"array_stride": 3 * 4, "step_mode": "vertex",
     "attributes": [{"format": "float32x3", "offset": 0, "var_name": "coord"}]},
    {"array_stride": 3 * 4, "step_mode": "vertex",
     "attributes": [{"format": "float32x3", "offset": 0, "var_name": "normal"}]},
    {"array_stride": 3 * 4, "step_mode": "vertex",
     "attributes": [{"format": "float32x3", "offset": 0, "var_name": "tangent"}]},
    {"array_stride": 2 * 4, "step_mode": "vertex",
     "attributes": [{"format": "float32x2", "offset": 0, "var_name": "texcoord"}]},
  ])
  pipeline_tex = Pipeline(shd_tex, target_format, primitive={"cull_mode": "back"})

  # Pipeline compartilhado pelas esferas vermelha e verde: usa as tangentes
  # da Sphere para o mapa de normal/relevo e o mapa separado de rugosidade.
  normal_shader = Shader(device, str(SHADER_ROOT / "ilum_frag" / "spot_normal_mapped.wgsl"),
                         light=light, space="world")
  configure_global_effects(normal_shader, second_light)
  normal_shader.set_vertex_buffers([
    {"array_stride": 3 * 4, "step_mode": "vertex",
     "attributes": [{"format": "float32x3", "offset": 0, "var_name": "coord"}]},
    {"array_stride": 3 * 4, "step_mode": "vertex",
     "attributes": [{"format": "float32x3", "offset": 0, "var_name": "normal"}]},
    {"array_stride": 3 * 4, "step_mode": "vertex",
     "attributes": [{"format": "float32x3", "offset": 0, "var_name": "tangent"}]},
    {"array_stride": 2 * 4, "step_mode": "vertex",
     "attributes": [{"format": "float32x2", "offset": 0, "var_name": "texcoord"}]},
  ])
  normal_pipeline = Pipeline(normal_shader, target_format, primitive={"cull_mode": "back"})

  # Cada material/textura e registrado no(s) shader(s) que o usam.
  shader.add_material(red)
  shader.add_material(green)
  shd_tex.add_material(brown)
  shd_tex.add_material(yellow)
  shd_tex.add_texture_set(wood_set)
  shd_tex.add_texture_set(brick_set)
  normal_shader.add_material(red)
  normal_shader.add_material(green)
  normal_textures = TextureSet([
    normal_map, normal_sampler, roughness_map, roughness_sampler,
  ])
  red_roughness_textures = TextureSet([
    flat_normal, normal_sampler, roughness_map, roughness_sampler,
  ])
  normal_shader.add_texture_set(normal_textures)
  normal_shader.add_texture_set(red_roughness_textures)

  # Pes da mesa: 4 cubos nos cantos, ate a base do tampo (y=0).
  leg_h, leg_w, leg_off = 1.0, 0.3, 1.7
  legs = [make_leg(pipeline_tex, brown, wood_set, cube, x, z, leg_h, leg_w)
          for x in (-leg_off, leg_off) for z in (-leg_off, leg_off)]

  # build scene: o pipeline da raiz (sem textura) e herdado pelas bolas;
  # os nos com decal trocam para pipeline_tex.
  root = Node(pipeline,
              nodes = [
                        Node(pipeline_tex, trf_table, [brown, wood_set], [cube]),
                        *legs,
                        Node(pipeline_tex, trf_yellow, [yellow, brick_set], [cube]),
                        Node(normal_pipeline, trf_red, [red, red_roughness_textures], [sphere]),
                        Node(normal_pipeline, trf_green, [green, normal_textures], [sphere]),
                      ]
              )
  scene = Scene(root)

def draw () -> None:
  target_texture = context.get_current_texture()
  renderer.render(target_texture, scene, camera)

def on_key (event: Any) -> None:
  if event["key"] == "q":
    canvas.close()

def main () -> None:
  global canvas, device, context, renderer

  canvas = RenderCanvas(size=(640, 480), title="Mesa com luz de spot", update_mode="continuous", max_fps=60)
  adapter = wgpu.gpu.request_adapter_sync()
  device = adapter.request_device_sync()
  context = canvas.get_context("wgpu")
  # formato preferido COM "-srgb": a GPU codifica de linear para sRGB
  # automaticamente na saída — correto desde que o shader faça a conta de
  # iluminação em espaço linear.
  target_format = context.get_preferred_format(device.adapter)
  context.configure(device=device, format=target_format)

  renderer = Renderer(device, depth_test=True, clear_value=(1.0, 1.0, 1.0, 1.0))

  initialize(device, target_format)

  canvas.add_event_handler(on_key, "key_down")
  canvas.request_draw(draw)
  loop.run()

if __name__ == "__main__":
  main()
