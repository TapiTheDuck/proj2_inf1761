struct Matrix {
  vertex: mat4x4<f32>,
  normal: mat4x4<f32>,
}
@group(1) @binding(0) var<storage, read> matrix: array<Matrix>;

struct LightBuffer {
  position: vec4<f32>,
  diffuse: vec4<f32>,
  specular: vec4<f32>,
}

struct Global {
  projection: mat4x4<f32>,
  light_ambient: vec3<f32>,
  light_diffuse: vec3<f32>,
  light_specular: vec3<f32>,
  light_position: vec4<f32>,
  light_direction: vec3<f32>,
  light_cutoff: f32,
  light_exponent: f32,
  camera_position: vec4<f32>,
  light2: LightBuffer,
  fog_color: vec4<f32>,
  fog_start: f32,
  fog_end: f32,
}
@group(0) @binding(0) var<uniform> global: Global;

struct Material {
  base_color: vec3<f32>,
  opacity: f32,
  specular_color: vec3<f32>,
  shininess: f32,
}
@group(2) @binding(0) var<uniform> material: Material;

@group(3) @binding(0) var normal_texture: texture_2d<f32>;
@group(3) @binding(1) var normal_sampler: sampler;
@group(3) @binding(2) var roughness_texture: texture_2d<f32>;
@group(3) @binding(3) var roughness_sampler: sampler;

struct VertexOutput {
  @builtin(position) clip_position: vec4<f32>,
  @location(0) normal: vec3<f32>,
  @location(1) tangent: vec3<f32>,
  @location(2) position: vec3<f32>,
  @location(3) texcoord: vec2<f32>,
}

@vertex
fn vs_main(
  @builtin(instance_index) instance_index: u32,
  @location(0) coord: vec3<f32>,
  @location(1) normal: vec3<f32>,
  @location(2) tangent: vec3<f32>,
  @location(3) texcoord: vec2<f32>
) -> VertexOutput {
  let m = matrix[instance_index];
  let p = m.vertex * vec4<f32>(coord, 1.0);
  var out: VertexOutput;
  out.position = p.xyz;
  out.normal = (m.normal * vec4<f32>(normal, 0.0)).xyz;
  out.tangent = (m.vertex * vec4<f32>(tangent, 0.0)).xyz;
  out.texcoord = texcoord;
  out.clip_position = global.projection * p;
  return out;
}

// Texture uses rgba8unorm-srgb in the shared Texture class. Convert the
// linearized sample back to encoded channels before decoding the normal.
fn linear_to_srgb(value: f32) -> f32 {
  if (value <= 0.0031308) {
    return value * 12.92;
  }
  return 1.055 * pow(value, 1.0 / 2.4) - 0.055;
}

@fragment
fn fs_main(in: VertexOutput) -> @location(0) vec4<f32> {
  let base_normal = normalize(in.normal);
  let tangent = normalize(in.tangent - base_normal * dot(base_normal, in.tangent));
  let bitangent = normalize(cross(base_normal, tangent));
  let sampled = textureSample(normal_texture, normal_sampler, in.texcoord).rgb;
  let encoded_normal = vec3<f32>(linear_to_srgb(sampled.r),
                                 linear_to_srgb(sampled.g),
                                 linear_to_srgb(sampled.b));
  let tangent_normal = normalize(encoded_normal * 2.0 - vec3<f32>(1.0));
  let normal = normalize(tangent * tangent_normal.x
                         + bitangent * tangent_normal.y
                         + base_normal * tangent_normal.z);
  // noise.png is grayscale roughness data. Texture loads use sRGB, so
  // restore the source channel value before interpreting it as roughness.
  let roughness_sample = textureSample(roughness_texture, roughness_sampler, in.texcoord).r;
  let roughness = clamp(linear_to_srgb(roughness_sample), 0.0, 1.0);
  let specular_power = mix(96.0, 4.0, roughness);
  let specular_level = mix(1.0, 0.25, roughness);
  let view = normalize(global.camera_position.xyz - in.position);

  // Existing SpotLight contribution with its per-fragment cone attenuation.
  let to_spot = global.light_position.xyz - in.position;
  let spot_light = normalize(to_spot);
  let cone_cosine = dot(-spot_light, normalize(global.light_direction));
  var spot_factor = 0.0;
  if (cone_cosine >= global.light_cutoff) {
    if (global.light_exponent == 0.0) {
      spot_factor = 1.0;
    } else {
      spot_factor = pow(max(cone_cosine, 0.0), global.light_exponent);
    }
  }

  var color = material.base_color * global.light_ambient;
  let spot_ndotl = max(dot(normal, spot_light), 0.0);
  if (spot_ndotl > 0.0 && spot_factor > 0.0) {
    color += spot_factor * material.base_color * global.light_diffuse * spot_ndotl;
    let reflected = normalize(reflect(-spot_light, normal));
    color += spot_factor * specular_level * material.specular_color * global.light_specular
      * pow(max(dot(reflected, view), 0.0), specular_power);
  }

  // Second, point-light contribution (diffuse + specular).
  let point_light = normalize(global.light2.position.xyz - in.position);
  let point_ndotl = max(dot(normal, point_light), 0.0);
  if (point_ndotl > 0.0) {
    color += material.base_color * global.light2.diffuse.rgb * point_ndotl;
    let reflected = normalize(reflect(-point_light, normal));
    color += specular_level * material.specular_color * global.light2.specular.rgb
      * pow(max(dot(reflected, view), 0.0), specular_power);
  }

  let distance_to_camera = distance(in.position, global.camera_position.xyz);
  let fog_factor = clamp((distance_to_camera - global.fog_start)
                         / max(global.fog_end - global.fog_start, 0.0001), 0.0, 1.0);
  return vec4<f32>(mix(color, global.fog_color.rgb, fog_factor), material.opacity);
}
