struct Matrix {
  vertex: mat4x4<f32>,
  normal: mat4x4<f32>,
}
@group(1) @binding(0) var<storage, read> matrix: array<Matrix>;

struct LightBuffer {
  position: vec4<f32>,
  diffuse: vec4<f32>,
  specular: vec4<f32>,
}

struct Global {
  projection: mat4x4<f32>,     // espaco de iluminacao -> NDC
  light_ambient: vec3<f32>,
  light_diffuse: vec3<f32>,
  light_specular: vec3<f32>,
  light_position: vec4<f32>,   // spos (w = 1)
  light_direction: vec3<f32>,  // sdir (unitario)
  light_cutoff: f32,           // cos(theta), theta = angulo de abertura
  light_exponent: f32,         // sexp, expoente de concentracao
  camera_position: vec4<f32>,  // posicao da camera no espaco de iluminacao
  light2: LightBuffer,
  fog_color: vec4<f32>,
  fog_start: f32,
  fog_end: f32,
}
@group(0) @binding(0) var<uniform> global: Global;

struct Material {
  base_color: vec3<f32>,
  opacity: f32,

  specular_color: vec3<f32>,
  shininess: f32,
}
@group(2) @binding(0) var<uniform> material: Material;

@group(3) @binding(0) var decal_texture: texture_2d<f32>;
@group(3) @binding(1) var decal_sampler: sampler;

fn point_light_contribution(normal: vec3<f32>, light: vec3<f32>, view: vec3<f32>, albedo: vec3<f32>) -> vec3<f32> {
  let ndotl = max(dot(normal, light), 0.0);
  var color = albedo * global.light2.diffuse.rgb * ndotl;
  if (ndotl > 0.0) {
    let reflected = normalize(reflect(-light, normal));
    color += material.specular_color * global.light2.specular.rgb
      * pow(max(dot(reflected, view), 0.0), material.shininess);
  }
  return color;
}

struct VertexOutput {
  @builtin(position) clip_position: vec4<f32>,
  @location(0) normal: vec3<f32>,
  @location(1) position: vec3<f32>,  // ponto iluminado, no espaco de iluminacao
  @location(2) texcoord: vec2<f32>,
}

// Luz de spot com iluminacao por fragmento. Diferente de lit.wgsl, o vertex
// shader NAO entrega o vetor da luz interpolado: entrega a POSICAO do ponto
// (que varia linearmente na face, logo a interpolacao e exata) e o vetor
// para a luz, o cosseno do cone e o coeficiente de spot sao todos calculados
// em fs_main, para cada fragmento. Isso e essencial para o cone: as faces
// da mesa tem so 2 triangulos, e interpolar um coeficiente de spot calculado
// nos vertices deixaria o cone completamente errado.
@vertex
fn vs_main (@builtin(instance_index) instance_index: u32, @location(0) coord: vec3<f32>, @location(1) normal: vec3<f32>, @location(2) tangent: vec3<f32>, @location(3) texcoord: vec2<f32>) -> VertexOutput {
  let m = matrix[instance_index];
  var out: VertexOutput;
  let p = m.vertex * vec4<f32>(coord, 1.0);
  out.position = p.xyz;
  out.normal = (m.normal * vec4<f32>(normal, 0.0)).xyz;
  out.texcoord = texcoord;
  out.clip_position = global.projection * p;
  return out;
}

@fragment
fn fs_main (in: VertexOutput) -> @location(0) vec4<f32> {
  let normal = normalize(in.normal);
  // l: vetor unitario do ponto iluminado para a fonte (l = spos - p, normalizado)
  let light = normalize(global.light_position.xyz - in.position);
  let view = normalize(global.camera_position.xyz - in.position);

  // c = -l . sdir: cosseno do angulo entre a direcao do spot e o ponto
  let c = dot(-light, normalize(global.light_direction));

  // kspot = max(c,0)^sexp dentro do cone (c >= cos theta), 0 fora dele
  var kspot = 0.0;
  if (c >= global.light_cutoff) {
    if (global.light_exponent == 0.0) {
      kspot = 1.0;  // sexp = 0: intensidade constante no interior do cone
    } else {
      kspot = pow(max(c, 0.0), global.light_exponent);
    }
  }

  // O ambiente nao depende do cone; kspot multiplica a intensidade (cor)
  // difusa e especular da fonte, que e o que o spot de fato ilumina.
  // Decal: o texel modula a cor base do material (padronagem de cor).
  let albedo = material.base_color * textureSample(decal_texture, decal_sampler, in.texcoord).rgb;
  var color = albedo * global.light_ambient;
  let ndotl = dot(normal, light);
  if (ndotl > 0.0 && kspot > 0.0) {
    color += kspot * albedo * global.light_diffuse * ndotl;
    let refl = normalize(reflect(-light, normal));
    color += kspot * material.specular_color * global.light_specular * pow(max(0.0, dot(refl, view)), material.shininess);
  }
  let point_delta = global.light2.position.xyz - in.position;
  let point_distance = length(point_delta);
  let point_light = normalize(point_delta);
  // Localized attenuation creates a visible warm hotspot on the tabletop.
  let point_attenuation = 1.0 / (1.0 + 0.35 * point_distance * point_distance);
  color += point_attenuation * point_light_contribution(normal, point_light, view, albedo);
  let distance_to_camera = distance(in.position, global.camera_position.xyz);
  let fog_factor = clamp((distance_to_camera - global.fog_start)
                         / max(global.fog_end - global.fog_start, 0.0001), 0.0, 1.0);
  return vec4<f32>(mix(color, global.fog_color.rgb, fog_factor), 1.0);
}
